# Classroom hydroponics — teacher resources

These are blank teaching materials, not student work.
The interactive slideshow opens in a browser. Its photos and videos need internet.
Use your own Kahoot session or the built-in backup quiz; the old PIN was removed.

## Teaching notes

### Project syllabus
The original project overview, assessment weights, and final design defense.
Adapt the pacing and standards alignment to your course.
Source: Hydroponics_Project_Syllabus.pdf

### How much land does food take?
Compare diets, calculate farmland, and support a claim with numbers.
Uses a class of six; change the multiplier for your group.
Source: Science 1.1.pdf

### Where did your breakfast grow?
Use food labels, climate, and water to explain where crops grow.
Includes Spanish prompts and sentence starters. Science 1.3 repeats this worksheet and is omitted.
Source: Science 1.2.pdf

### Garden field guide
Observe a garden and identify what limits plant growth.
Compare outdoor conditions with what the hydroponic system can control.
Source: Science 1.4.pdf

### The six missing pieces
Match plant needs to the reservoir, pump, tubing, nutrients, drainage, and monitoring.
Includes Spanish prompts and sentence starters.
Source: Science 1.5.pdf

### Vote and get ready
Choose a system job, define its criteria and constraints, and plan a first step.
Includes Spanish prompts and sentence starters.
Source: Science 1.6.pdf

### How many tees do we need?
Build branching models and explain the relationship between outlets and tees.
Earlier design: eight direct feeds and a bypass. For the current four paired routes, use three supply tees and three return tees; no bypass is shown.
Source: Science_1_7_-_Tubing_and_tees_-_packet - Google Docs.pdf

### Plants make it. We burn it.
Photosynthesis and respiration, with video prompts, four corners, a sorting activity, and a backup quiz.
Open in a browser. Arrow keys move between slides; videos and photographs need internet. The old Kahoot PIN has been removed.
Source: Science 3.2 Slideshow (Period 1) - download, then open.html · Google Drive

### Plants make it, we burn it — worksheet
Trace inputs and outputs, compare the two processes, and explain why plants also respire.
Companion to the slideshow. Use your own Kahoot or the deck’s backup questions.
Source: Science 3.2 Worksheet.pdf · Google Drive

## Budget
Historical estimates in USD, not receipt-verified spending or current prices.
Listed purchase: $767.06
Frame estimate: $141.00
Proposed addition: $101.00
Proposed additions are separate from the baseline.
See the CSV and website for price discrepancies and earlier-design allowances.

Public project: https://zacklinger.github.io/mrk-classroom/
