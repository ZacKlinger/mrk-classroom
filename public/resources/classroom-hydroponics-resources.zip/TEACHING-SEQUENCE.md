# Hydroponics teaching sequence

Adapted from the original 16-week unit plan. Flexible phases, not a fixed calendar.

## 1. Define & build
Engineering · about 3 weeks

Identify plant needs and compare designs against space, cost, and maintenance constraints.

Activity: Investigate food and land use, visit a garden, assign system jobs, then sketch and build a prototype.

Evidence: A design sketch and an explanation of why the chosen system meets the constraints.

## 2. Move the water
Physics · about 3 weeks

Explain how the pump, height, slope, and fittings affect water movement.

Activity: Model branching with tees. Connect the four paired routes, check for leaks, and measure flow while changing one variable.

Evidence: A labeled water-path diagram and before-and-after flow measurements.

## 3. Light & living plants
Biology · about 2 weeks

Connect photosynthesis and cellular respiration to plant growth.

Activity: Use the slideshow and companion worksheet. Germinate lettuce, transplant seedlings, and compare light conditions.

Evidence: A plant observation log and an explanation of how light supports growth.

## 4. Mix & measure
Chemistry · about 2 weeks

Explain solutions, nutrients, and pH, and connect water conditions to plant health.

Activity: Mix nutrient solution, practice measurement, and compare changes in pH or concentration under teacher guidance.

Evidence: A measurement record and a cause-and-effect explanation.

## 5. Keep the system healthy
Matter & systems · about 2 weeks

Trace matter through the system and recognize disturbances over time.

Activity: Track growth and water use. Diagnose problems such as algae or blocked drainage and document a response.

Evidence: A claim supported by observations and data from the system.

## 6. Improve & share
Optimization · about 3 weeks + culmination

Use evidence to improve the design and evaluate sustainability trade-offs.

Activity: Revise the system, compare hydroponics with soil growing, and prepare a demonstration, poster, or presentation. Harvest when ready.

Evidence: A design defense and reflection on what changed, why it changed, and what the evidence shows.

